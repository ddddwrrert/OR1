/**
 * Opt-in floor graft.
 *
 * `DSH_EVOLVE_FLOOR=1` replaces parent selection and mutation. The loop, the
 * official evaluator, and the survival rule stay as they are. The parent file
 * is always the best average. A lower-average program only donates the change
 * that raised the hard seeds.
 *
 * Set the variable before the harness starts.
 *
 * @module dsh-evolve-loop/floor/install
 */

import floorMutate from '../providers/floor-mutate.js'
import floorSelect from '../providers/floor-select.js'

/** The environment variable that turns the graft on. */
export const ENV_FLAG = 'DSH_EVOLVE_FLOOR'

/**
 * @param {Record<string, string|undefined>} [env=process.env]
 * @returns {boolean}
 */
export function requested(env = process.env) {
  const value = `${env[ENV_FLAG] ?? ''}`.trim().toLowerCase()
  return value === '1' || value === 'true' || value === 'on'
}

/**
 * @param {object} evolve
 * @returns {{ installed: string[], dispose: () => void }}
 */
export function installFloorProviders(evolve) {
  const providers = {
    select: floorSelect,
    mutate: floorMutate,
  }
  const disposers = []
  const installed = []
  for (const [slot, provider] of Object.entries(providers)) {
    disposers.push(evolve.register(slot, provider))
    installed.push(`${slot}=${provider.name}`)
  }
  return {
    installed,
    dispose: () => {
      for (const dispose of disposers.reverse()) dispose()
    },
  }
}
