/**
 * Floor graft.
 *
 * The official parent is the program with the best average. A program that
 * scores higher on the hard seeds and lower on the average is not the next
 * file. Its hard-seed change is copied onto the parent, and the copy replaces
 * the parent only when the official average rises.
 *
 * Seed lists come from the evaluator record (`metrics.cases`). This module
 * does not change that average.
 *
 * @module dsh-evolve-loop/floor/graft
 */

/** Assignments for later children. Child fitness is joined from the population. */
export const TURN_LOG = 'floor/turns.jsonl'

/** How many mean-children of one parent may fail to raise the average before both turns paste. */
export const FLAT_MEAN = 3

/** How many pastes may raise the hard seeds and still lose the average before a second path is allowed. */
export const CONFLICT_GRAFTS = 3

/** Hard seeds named in one worker prompt. */
export const FOCUS_LIMIT = 8

/**
 * Per-seed scores from an official eval record.
 * @param {object|null|undefined} evalResult
 * @returns {{ seed: number, score: number }[]}
 */
export function casesFromEval(evalResult) {
  const metrics = evalResult?.metrics && typeof evalResult.metrics === 'object'
    ? evalResult.metrics
    : evalResult
  const rows = metrics?.cases ?? metrics?.case_results ?? metrics?.seed_scores
  if (!Array.isArray(rows)) return []
  const cases = []
  for (let index = 0; index < rows.length; index += 1) {
    const row = rows[index]
    if (typeof row === 'number' && Number.isFinite(row)) {
      cases.push({ seed: index, score: row })
      continue
    }
    if (!row || typeof row !== 'object') continue
    const score = firstScore(row)
    if (score === undefined) continue
    const seed = firstSeed(row, index)
    cases.push({ seed, score })
  }
  return cases
}

/**
 * The lowest third of the parent's seeds. Ties break by seed number, and the
 * list stays that exact length, so a high plateau is not pulled in.
 * @param {{ seed: number, score: number }[]} cases
 * @returns {number[]}
 */
export function floorSeeds(cases) {
  if (!Array.isArray(cases) || cases.length < 2) return []
  const scores = cases.map(row => row.score)
  if (Math.min(...scores) === Math.max(...scores)) return []
  const keep = Math.max(1, Math.floor(cases.length / 3))
  return [...cases]
    .sort((left, right) => left.score - right.score || left.seed - right.seed)
    .slice(0, keep)
    .map(row => row.seed)
}

/**
 * Hard-seed gain and easy-seed damage of one candidate against the parent.
 * Damage is only a tie-break: the paste copies the gain and leaves the damage behind.
 * @param {{ seed: number, score: number }[]} parentCases
 * @param {{ seed: number, score: number }[]} childCases
 * @returns {{ gain: number, damage: number }}
 */
export function donorParts(parentCases, childCases) {
  const parent = seedMap(parentCases)
  const child = seedMap(childCases)
  const floor = new Set(floorSeeds(parentCases))
  let gain = 0
  let damage = 0
  for (const [seed, parentScore] of parent) {
    if (!child.has(seed)) continue
    const delta = child.get(seed) - parentScore
    if (floor.has(seed)) gain += Math.max(0, delta)
    else damage += Math.max(0, -delta)
  }
  return { gain, damage }
}

/**
 * Alive candidate with the highest official fitness. An earlier id wins a tie,
 * so an all-zero population stays on the baseline.
 * @param {object[]} rows
 * @returns {object}
 */
export function incumbentOf(rows) {
  const alive = rows.filter(row => row.survival === 'yes')
  if (alive.length === 0) throw new Error('the population has no alive candidate to select')
  return [...alive].sort((left, right) => {
    const delta = (right.fitness ?? 0) - (left.fitness ?? 0)
    if (delta !== 0) return delta
    return left.id < right.id ? -1 : 1
  })[0]
}

/**
 * The candidate that raised the parent's hard seeds the most, among candidates
 * whose official average is not higher. More gain wins. Less damage breaks a tie.
 * @param {{ id: string, fitness: number, cases: { seed: number, score: number }[] }} parent
 * @param {{ id: string, fitness: number, cases: { seed: number, score: number }[] }[]} others
 * @returns {{ id: string, fitness: number, gain: number, damage: number, cases: object[] }|null}
 */
export function pickDonor(parent, others) {
  let best = null
  for (const row of others) {
    if (row.id === parent.id) continue
    if ((row.fitness ?? 0) > (parent.fitness ?? 0)) continue
    if (!Array.isArray(row.cases) || row.cases.length === 0) continue
    const parts = donorParts(parent.cases, row.cases)
    if (!(parts.gain > 0)) continue
    const candidate = { ...row, ...parts }
    if (!best || betterDonor(candidate, best)) best = candidate
  }
  return best
}

/**
 * Mean-children of this parent that failed to raise its official fitness, counting from the latest.
 * @param {object[]} turns
 * @param {string} parentId
 * @returns {number}
 */
export function meanFlatStreak(turns, parentId) {
  const scored = turns.filter(row => (
    row.parent === parentId && row.kind === 'mean' && typeof row.childFitness === 'number'
  ))
  let streak = 0
  for (let index = scored.length - 1; index >= 0; index -= 1) {
    if (scored[index].childFitness > scored[index].parentFitness) break
    streak += 1
  }
  return streak
}

/**
 * Latest pastes that raised the hard seeds and still lost the official average.
 * @param {object[]} turns
 * @param {string} parentId
 * @returns {number}
 */
export function graftConflictStreak(turns, parentId) {
  const scored = turns.filter(row => (
    row.parent === parentId && row.kind === 'graft' && typeof row.childFitness === 'number'
  ))
  let streak = 0
  for (let index = scored.length - 1; index >= 0; index -= 1) {
    const row = scored[index]
    if (!(row.floorGain > 0) || row.childFitness > row.parentFitness) break
    streak += 1
  }
  return streak
}

/**
 * `mean` keeps improving the parent's average. `graft` pastes one hard-seed repair.
 * After three mean-children fail to raise this parent, later children paste.
 * @param {object[]} turns - already joined with child fitness
 * @param {string} parentId
 * @returns {'mean'|'graft'}
 */
export function nextKind(turns, parentId) {
  const assigned = turns.filter(row => row.parent === parentId)
  if (meanFlatStreak(turns, parentId) >= FLAT_MEAN) return 'graft'
  return assigned.length % 2 === 0 ? 'mean' : 'graft'
}

/**
 * Attach official fitness and hard-seed gain to each logged turn.
 * @param {object[]} turns
 * @param {Map<string, number>} fitnessById
 * @param {Map<string, { seed: number, score: number }[]>} casesById
 * @returns {object[]}
 */
export function annotateTurns(turns, fitnessById, casesById) {
  return turns.map(row => {
    const childFitness = fitnessById.has(row.id) ? fitnessById.get(row.id) : undefined
    const parentCases = casesById.get(row.parent) ?? []
    const childCases = casesById.get(row.id) ?? []
    const floorGain = parentCases.length > 0 && childCases.length > 0
      ? donorParts(parentCases, childCases).gain
      : 0
    return {
      ...row,
      childFitness: typeof childFitness === 'number' ? childFitness : undefined,
      floorGain,
    }
  })
}

/**
 * Lines in the donor that the parent does not already have.
 * @param {string|undefined} parentText
 * @param {string|undefined} donorText
 * @param {number} [limit=40]
 * @returns {string[]}
 */
export function addedLines(parentText, donorText, limit = 40) {
  if (typeof parentText !== 'string' || typeof donorText !== 'string') return []
  if (parentText === donorText) return []
  const known = new Set(parentText.split('\n').map(line => line.trim()).filter(line => line !== ''))
  const added = []
  for (const line of donorText.split('\n')) {
    const trimmed = line.trim()
    if (trimmed === '' || known.has(trimmed)) continue
    added.push(line)
    if (added.length >= limit) break
  }
  return added
}

/**
 * Hard seeds to name in this prompt: the ones the donor actually raised, at most eight.
 * @param {{ seed: number, score: number }[]} parentCases
 * @param {{ seed: number, score: number }[]|null} donorCases
 * @returns {{ seed: number, parentScore: number, donorScore: number|null }[]}
 */
export function focusRows(parentCases, donorCases) {
  const parent = seedMap(parentCases)
  const donor = donorCases ? seedMap(donorCases) : null
  const rows = floorSeeds(parentCases).map(seed => ({
    seed,
    parentScore: parent.get(seed),
    donorScore: donor && donor.has(seed) ? donor.get(seed) : null,
  }))
  const raised = rows.filter(row => row.donorScore !== null && row.donorScore > row.parentScore)
  const chosen = (raised.length > 0 ? raised : rows)
    .sort((left, right) => {
      const gain = (right.donorScore ?? right.parentScore) - right.parentScore
        - ((left.donorScore ?? left.parentScore) - left.parentScore)
      if (gain !== 0) return gain
      return left.parentScore - right.parentScore || left.seed - right.seed
    })
    .slice(0, FOCUS_LIMIT)
  return chosen
}

/**
 * Worker instruction. The file it edits is always the official parent.
 * @param {object} args
 * @param {'mean'|'graft'} args.kind
 * @param {number} [args.parentFitness]
 * @param {{ seed: number, parentScore: number, donorScore: number|null }[]} [args.focus]
 * @param {{ id: string, fitness: number, intent?: string, added?: string[] }|null} [args.donor]
 * @param {boolean} [args.secondPath]
 * @returns {string}
 */
export function buildFloorInstruction(args) {
  const lines = [
    'Read the task statement and the parent solution in this directory.',
    'The parent file is the program with the best average over every seed. Keep that program as the base.',
    'The official score is the average of all seeds. A change is kept only when that average rises.',
  ]
  if (typeof args.parentFitness === 'number' && Number.isFinite(args.parentFitness)) {
    lines.push(`The parent candidate's official fitness was ${formatNumber(args.parentFitness)}.`)
  }
  if (args.kind === 'mean') {
    lines.push(
      '',
      'This attempt raises the average. Make one change to the parent solution.',
      'Leave the parts that already score well on the easy seeds in place.',
    )
  } else {
    lines.push(
      '',
      'This attempt pastes one repair for the hard seeds. Do not replace the parent\'s solution.',
      'Build the parent\'s answer first. Then add one repair for the weak part of that answer.',
      'Run the repair when the instance looks hard: it is large, it is dense, or one cost term dominates the answer.',
      'Do not branch on the seed number.',
    )
    const focus = args.focus ?? []
    if (focus.length > 0) {
      lines.push('', 'Hard seeds on the parent:')
      for (const row of focus) {
        const donorText = row.donorScore === null ? '' : `, other program ${formatNumber(row.donorScore)}`
        lines.push(`- seed ${row.seed}: parent ${formatNumber(row.parentScore)}${donorText}`)
      }
    }
    if (args.donor) {
      lines.push('', `The other program is ${args.donor.id}, official fitness ${formatNumber(args.donor.fitness)}.`)
      lines.push('Copy only the part of it that raised the hard seeds. Leave out the part that lowered the easy seeds.')
      if (args.donor.intent) lines.push(`It reported: ${args.donor.intent}`)
      if (args.donor.added?.length > 0) {
        lines.push('Lines present in that program and absent from the parent:')
        for (const line of args.donor.added) lines.push(`  ${line}`)
      }
    } else if (focus.length === 0) {
      lines.push('', 'This parent has no per-seed scores yet. Add the repair from the shape of the instance alone.')
    }
    if (args.secondPath) {
      lines.push(
        '',
        'Earlier pastes raised the hard seeds and lowered the average.',
        'Keep the current solver as the default path. Add a second block that runs only for the hard-looking instances described above.',
      )
    }
  }
  lines.push(
    '',
    'Edit only the solution code between the #EVOLVE_START and #EVOLVE_END markers; leave all other task files and code unchanged.',
    'This directory is one allocated candidate. Do not write a second solution beside it.',
    'Do not run the task\'s official evaluator. The search scores this candidate after you finish.',
    '',
    'Before you finish, write evolve_meta.json in this directory:',
    '```json',
    '{',
    `  "assignedKind": "${args.kind}",`,
    '  "mutationIntent": "one sentence: the single change"',
    '}',
    '```',
  )
  return lines.join('\n')
}

/**
 * @param {string|undefined} raw
 * @returns {object[]}
 */
export function parseTurns(raw) {
  if (!raw) return []
  const rows = []
  for (const line of raw.split('\n')) {
    if (line.trim() === '') continue
    try {
      rows.push(JSON.parse(line))
    } catch { /* a truncated final line is ignored */ }
  }
  return rows
}

/**
 * @param {object} row
 * @returns {number|undefined}
 */
function firstScore(row) {
  for (const key of ['score', 'absolute_score', 'raw_score', 'rawScore']) {
    const value = row[key]
    if (typeof value === 'number' && Number.isFinite(value)) return value
  }
  return undefined
}

/**
 * @param {object} row
 * @param {number} index
 * @returns {number}
 */
function firstSeed(row, index) {
  if (typeof row.seed === 'number' && Number.isFinite(row.seed)) return row.seed
  const raw = row.caseId ?? row.case_id ?? row.id
  const parsed = typeof raw === 'number' ? raw : Number.parseInt(String(raw ?? ''), 10)
  return Number.isFinite(parsed) ? parsed : index
}

/**
 * @param {{ seed: number, score: number }[]} cases
 * @returns {Map<number, number>}
 */
function seedMap(cases) {
  const map = new Map()
  for (const row of cases ?? []) map.set(row.seed, row.score)
  return map
}

/**
 * @param {{ gain: number, damage: number, id: string }} left
 * @param {{ gain: number, damage: number, id: string }} right
 * @returns {boolean}
 */
function betterDonor(left, right) {
  if (left.gain !== right.gain) return left.gain > right.gain
  if (left.damage !== right.damage) return left.damage < right.damage
  return left.id < right.id
}

/**
 * @param {number} value
 * @returns {string}
 */
function formatNumber(value) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return String(value)
  return Number.isInteger(value) ? String(value) : value.toFixed(4).replace(/\.?0+$/, '')
}
