/**
 * Parent selection for the floor graft.
 *
 * The next file is always the alive candidate with the best official average.
 * A program that only wins the hard seeds stays off this slot.
 *
 * @module dsh-evolve-loop/providers/floor-select
 */

import { incumbentOf } from '../floor/graft.js'

export const name = 'floor-select'

/**
 * @param {object} population
 * @returns {Promise<string>}
 */
export async function select(population) {
  const rows = await population.rows()
  return incumbentOf(rows).id
}

export default { name, select }
