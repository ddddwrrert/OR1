/**
 * Mutation provider for the floor graft.
 *
 * One budget unit still creates one child of the official parent. Even turns
 * improve that parent's average. Odd turns paste a hard-seed repair from a
 * program that lost the average. The worker never sees the other program's
 * directory; the prompt carries the seeds and the added lines.
 *
 * @module dsh-evolve-loop/providers/floor-mutate
 */

import {
  CONFLICT_GRAFTS,
  TURN_LOG,
  addedLines,
  annotateTurns,
  buildFloorInstruction,
  casesFromEval,
  focusRows,
  graftConflictStreak,
  nextKind,
  parseTurns,
  pickDonor,
} from '../floor/graft.js'

export const name = 'floor-mutate'

const PROGRAMS = ['solution.cpp', 'solution.py']

/**
 * @returns {string}
 */
export function persona() {
  return 'You are a solution worker in a heuristic-contest search. '
    + 'The parent program is the base. Implement the single assigned change in your directory. '
    + 'IMPLEMENT A SINGLE SOLUTION. DO NOT ATTEMPT MULTIPLE SOLUTIONS.'
}

/**
 * @param {object} options
 * @param {string} options.parent
 * @param {string} [options.model]
 * @param {string[]} [options.allowedTools]
 * @param {boolean} [options.allowShell=true]
 * @param {object} evolve
 * @returns {Promise<{ id: string, dir: string }>}
 */
export async function mutate(options, evolve) {
  const { parent, model, allowedTools, allowShell = true } = options ?? {}
  if (!parent) throw new Error('mutate needs a parent candidate id')

  const files = evolve.files
  const rows = await evolve.population().rows()
  const parentRow = rows.find(row => row.id === parent)
  const parentFitness = typeof options.parentFitness === 'number' ? options.parentFitness : parentRow?.fitness
  const casesById = new Map()
  for (const row of rows) {
    casesById.set(row.id, await loadCases(files, row.id))
  }
  const turns = annotateTurns(
    parseTurns(await files.read(TURN_LOG)),
    new Map(rows.map(row => [row.id, row.fitness])),
    casesById,
  )
  const parentCases = casesById.get(parent) ?? []
  const donor = pickDonor(
    { id: parent, fitness: parentFitness ?? 0, cases: parentCases },
    rows.filter(row => row.id !== parent).map(row => ({
      id: row.id,
      fitness: row.fitness,
      cases: casesById.get(row.id) ?? [],
    })),
  )
  const kind = nextKind(turns, parent)
  const useDonor = kind === 'graft' && donor !== null
  const donorNote = useDonor ? await describeDonor(files, parent, donor) : null
  const instruction = buildFloorInstruction({
    kind,
    parentFitness: typeof parentFitness === 'number' ? parentFitness : undefined,
    focus: focusRows(parentCases, useDonor ? donor.cases : null),
    donor: donorNote,
    secondPath: kind === 'graft' && graftConflictStreak(turns, parent) >= CONFLICT_GRAFTS,
  })

  const candidate = await evolve.allocate(parent)
  await files.append(TURN_LOG, `${JSON.stringify({
    ts: new Date().toISOString(),
    id: candidate.id,
    parent,
    kind,
    donorId: useDonor ? donor.id : null,
    parentFitness: typeof parentFitness === 'number' ? parentFitness : null,
  })}\n`)

  try {
    await evolve.spawnWorker(candidate.dir, instruction, {
      label: kind === 'graft' ? 'floor-graft' : 'floor-mean',
      persona: persona(),
      model,
      allowShell,
      allowedTools,
    })
  } catch (error) {
    const currentRun = evolve.currentRun?.()
    if (currentRun?.signal?.aborted) throw error
  }
  return candidate
}

/**
 * @param {object} files
 * @param {string} candidateId
 * @returns {Promise<{ seed: number, score: number }[]>}
 */
async function loadCases(files, candidateId) {
  const raw = await files.read(`evals/${candidateId}.json`)
  if (!raw) return []
  try {
    const parsed = JSON.parse(raw)
    return casesFromEval(parsed)
  } catch {
    return []
  }
}

/**
 * @param {object} files
 * @param {string} parentId
 * @param {{ id: string, fitness: number }} donor
 * @returns {Promise<{ id: string, fitness: number, intent: string, added: string[] }>}
 */
async function describeDonor(files, parentId, donor) {
  const meta = await readMeta(files, donor.id)
  const parentText = await readProgram(files, parentId)
  const donorText = await readProgram(files, donor.id)
  return {
    id: donor.id,
    fitness: donor.fitness,
    intent: typeof meta?.mutationIntent === 'string' ? meta.mutationIntent.trim() : '',
    added: addedLines(parentText, donorText),
  }
}

/**
 * @param {object} files
 * @param {string} candidateId
 * @returns {Promise<object|undefined>}
 */
async function readMeta(files, candidateId) {
  const raw = await files.read(`candidates/${candidateId}/evolve_meta.json`)
  if (!raw) return undefined
  try {
    const parsed = JSON.parse(raw)
    return parsed && typeof parsed === 'object' ? parsed : undefined
  } catch {
    return undefined
  }
}

/**
 * @param {object} files
 * @param {string} candidateId
 * @returns {Promise<string|undefined>}
 */
async function readProgram(files, candidateId) {
  for (const name of PROGRAMS) {
    const text = await files.read(`candidates/${candidateId}/${name}`)
    if (typeof text === 'string') return text
  }
  return undefined
}

export default { name, mutate, persona }
